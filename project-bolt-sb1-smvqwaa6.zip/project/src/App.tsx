@@ .. @@
 import Dashboard from './pages/Dashboard';
 import AdminDashboard from './pages/admin/AdminDashboard';
 import UserManagement from './pages/admin/UserManagement';
+import BalanceManagement from './pages/admin/BalanceManagement';
+import TransferManagement from './pages/admin/TransferManagement';
+import NotificationCenter from './pages/admin/NotificationCenter';
 import Layout from './components/Layout';
 import ProtectedRoute from './components/ProtectedRoute';
@@ .. @@
             <Route path="/admin" element={
               <ProtectedRoute requireAdmin>
                 <AdminDashboard />
               </ProtectedRoute>
             } />
             <Route path="/admin/users" element={
               <ProtectedRoute requireAdmin>
                 <UserManagement />
               </ProtectedRoute>
             } />
+            <Route path="/admin/balance" element={
+              <ProtectedRoute requireAdmin>
+                <BalanceManagement />
+              </ProtectedRoute>
+            } />
+            <Route path="/admin/transfers" element={
+              <ProtectedRoute requireAdmin>
+                <TransferManagement />
+              </ProtectedRoute>
+            } />
+            <Route path="/admin/notifications" element={
+              <ProtectedRoute requireAdmin>
+                <NotificationCenter />
+              </ProtectedRoute>
+            } />
           </Routes>
         </Layout>
       </Router>