@@ .. @@
 import React, { useState, useEffect } from 'react';
 import { supabase } from '../lib/supabase';
+import TestConnection from '../components/TestConnection';
 import { User, DollarSign, Bell, Activity } from 'lucide-react';
@@ .. @@
   return (
     <div className="space-y-6">
+      <TestConnection />
+      
       <div className="flex justify-between items-center">
   )