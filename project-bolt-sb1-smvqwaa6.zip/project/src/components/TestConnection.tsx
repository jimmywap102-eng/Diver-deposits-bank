import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { CheckCircle, XCircle, Database } from 'lucide-react';

export default function TestConnection() {
  const [connectionStatus, setConnectionStatus] = useState<'testing' | 'connected' | 'error'>('testing');
  const [tableCount, setTableCount] = useState(0);
  const [userCount, setUserCount] = useState(0);

  useEffect(() => {
    testConnection();
  }, []);

  const testConnection = async () => {
    try {
      // Test basic connection
      const { data: tables, error: tablesError } = await supabase
        .from('profiles')
        .select('count', { count: 'exact', head: true });

      if (tablesError) throw tablesError;

      // Count users
      const { count: users } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Count all tables
      const tableNames = ['profiles', 'user_balances', 'notifications', 'mock_transfers', 'admin_activities'];
      let validTables = 0;

      for (const tableName of tableNames) {
        try {
          await supabase.from(tableName).select('count', { count: 'exact', head: true });
          validTables++;
        } catch (e) {
          console.log(`Table ${tableName} not found or accessible`);
        }
      }

      setTableCount(validTables);
      setUserCount(users || 0);
      setConnectionStatus('connected');
    } catch (error) {
      console.error('Connection test failed:', error);
      setConnectionStatus('error');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
      <div className="flex items-center space-x-3 mb-4">
        <Database className="h-6 w-6 text-blue-600" />
        <h2 className="text-lg font-semibold text-gray-900">Supabase Connection Status</h2>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          {connectionStatus === 'testing' && (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span className="text-sm text-gray-600">Testing connection...</span>
            </>
          )}
          {connectionStatus === 'connected' && (
            <>
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-600">Connected successfully!</span>
            </>
          )}
          {connectionStatus === 'error' && (
            <>
              <XCircle className="h-4 w-4 text-red-600" />
              <span className="text-sm text-red-600">Connection failed</span>
            </>
          )}
        </div>

        {connectionStatus === 'connected' && (
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-green-50 p-3 rounded">
              <div className="text-sm font-medium text-green-800">Database Tables</div>
              <div className="text-lg font-bold text-green-900">{tableCount}/5</div>
            </div>
            <div className="bg-blue-50 p-3 rounded">
              <div className="text-sm font-medium text-blue-800">Total Users</div>
              <div className="text-lg font-bold text-blue-900">{userCount}</div>
            </div>
          </div>
        )}

        {connectionStatus === 'error' && (
          <div className="bg-red-50 p-3 rounded mt-4">
            <p className="text-sm text-red-800">
              Database connection failed. Please check your Supabase configuration.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}