import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { DollarSign, TrendingUp, TrendingDown, Edit3, Save, X } from 'lucide-react';

interface UserBalance {
  id: string;
  user_id: string;
  balance: number;
  currency: string;
  is_frozen: boolean;
  last_updated: string;
  profiles: {
    full_name: string;
    email: string;
    status: string;
  };
}

export default function BalanceManagement() {
  const [balances, setBalances] = useState<UserBalance[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editBalance, setEditBalance] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchBalances();
  }, []);

  const fetchBalances = async () => {
    try {
      const { data, error } = await supabase
        .from('user_balances')
        .select(`
          *,
          profiles!user_balances_user_id_fkey (
            full_name,
            email,
            status
          )
        `)
        .order('last_updated', { ascending: false });

      if (error) throw error;
      setBalances(data || []);
    } catch (error) {
      console.error('Error fetching balances:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateBalance = async (userId: string, newBalance: number) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.rpc('update_user_balance', {
        target_user_id: userId,
        new_balance: newBalance,
        admin_id: user.id
      });

      if (error) throw error;
      
      await fetchBalances();
      setEditingId(null);
      setEditBalance('');
    } catch (error) {
      console.error('Error updating balance:', error);
    }
  };

  const toggleFreeze = async (userId: string, currentFrozen: boolean) => {
    try {
      const { error } = await supabase
        .from('user_balances')
        .update({ is_frozen: !currentFrozen })
        .eq('user_id', userId);

      if (error) throw error;
      await fetchBalances();
    } catch (error) {
      console.error('Error toggling freeze:', error);
    }
  };

  const startEdit = (balance: UserBalance) => {
    setEditingId(balance.id);
    setEditBalance(balance.balance.toString());
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditBalance('');
  };

  const saveEdit = (userId: string) => {
    const newBalance = parseFloat(editBalance);
    if (!isNaN(newBalance) && newBalance >= 0) {
      updateBalance(userId, newBalance);
    }
  };

  const filteredBalances = balances.filter(balance =>
    balance.profiles?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    balance.profiles?.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalBalance = balances.reduce((sum, balance) => sum + balance.balance, 0);
  const activeAccounts = balances.filter(b => !b.is_frozen).length;
  const frozenAccounts = balances.filter(b => b.is_frozen).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Balance Management</h1>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Balance</p>
              <p className="text-2xl font-bold text-gray-900">
                ${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Active Accounts</p>
              <p className="text-2xl font-bold text-gray-900">{activeAccounts}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <TrendingDown className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Frozen Accounts</p>
              <p className="text-2xl font-bold text-gray-900">{frozenAccounts}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Avg Balance</p>
              <p className="text-2xl font-bold text-gray-900">
                ${balances.length > 0 ? (totalBalance / balances.length).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <input
          type="text"
          placeholder="Search users by name or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      {/* Balance Table */}
      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Balance
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Updated
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredBalances.map((balance) => (
              <tr key={balance.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900">
                      {balance.profiles?.full_name}
                    </div>
                    <div className="text-sm text-gray-500">
                      {balance.profiles?.email}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {editingId === balance.id ? (
                    <div className="flex items-center space-x-2">
                      <input
                        type="number"
                        value={editBalance}
                        onChange={(e) => setEditBalance(e.target.value)}
                        className="w-32 px-2 py-1 border border-gray-300 rounded text-sm"
                        step="0.01"
                        min="0"
                      />
                      <button
                        onClick={() => saveEdit(balance.user_id)}
                        className="text-green-600 hover:text-green-800"
                      >
                        <Save className="h-4 w-4" />
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="text-red-600 hover:text-red-800"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-gray-900">
                        ${balance.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                      <button
                        onClick={() => startEdit(balance)}
                        className="text-indigo-600 hover:text-indigo-800"
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col space-y-1">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      balance.profiles?.status === 'active'
                        ? 'bg-green-100 text-green-800'
                        : balance.profiles?.status === 'suspended'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {balance.profiles?.status}
                    </span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      balance.is_frozen
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {balance.is_frozen ? 'Frozen' : 'Active'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(balance.last_updated).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => toggleFreeze(balance.user_id, balance.is_frozen)}
                    className={`px-3 py-1 rounded text-xs font-medium ${
                      balance.is_frozen
                        ? 'bg-green-100 text-green-800 hover:bg-green-200'
                        : 'bg-red-100 text-red-800 hover:bg-red-200'
                    }`}
                  >
                    {balance.is_frozen ? 'Unfreeze' : 'Freeze'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}